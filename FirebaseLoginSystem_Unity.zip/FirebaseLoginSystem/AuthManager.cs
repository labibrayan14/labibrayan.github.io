
using Firebase;
using Firebase.Auth;
using System.Collections.Generic;
using UnityEngine;

namespace AuthSystem
{
    public class AuthManager : MonoBehaviour
    {
        public static AuthManager Instance { get; private set; }
        public FirebaseAuth Auth { get; private set; }

        private Dictionary<string, IAuthProvider> providers = new();

        public IReadOnlyDictionary<string, IAuthProvider> Providers => providers;

        public FirebaseUser CurrentUser => Auth?.CurrentUser;

        private void Awake()
        {
            if (Instance != null)
            {
                Destroy(gameObject);
                return;
            }

            Instance = this;
            DontDestroyOnLoad(gameObject);
            InitializeFirebase();
        }

        private void Start()
        {
            RegisterProviders();
        }

        private void InitializeFirebase()
        {
            FirebaseApp.CheckAndFixDependenciesAsync().ContinueWith(task =>
            {
                if (task.Result == DependencyStatus.Available)
                {
                    Auth = FirebaseAuth.DefaultInstance;

                    if (Auth.CurrentUser != null)
                    {
                        Debug.Log($"[AuthManager] Session detected: {Auth.CurrentUser.UserId}");
                        AuthEvents.TriggerLoginSuccess(Auth.CurrentUser.UserId);
                    }

                    Auth.StateChanged += HandleAuthStateChanged;
                    HandleAuthStateChanged(this, null);
                }
                else
                {
                    Debug.LogError("[AuthManager] Firebase Error: " + task.Result);
                }
            });
        }

        private void RegisterProviders()
        {
            var found = FindObjectsOfType<MonoBehaviour>(true);
            foreach (var mono in found)
            {
                if (mono is IAuthProvider provider && !providers.ContainsKey(provider.ProviderId))
                {
                    providers.Add(provider.ProviderId, provider);
                    Debug.Log($"[AuthManager] Registered: {provider.ProviderId}");
                }
            }

            FindObjectOfType<AuthUIBuilder>()?.BuildUI();
        }

        private void HandleAuthStateChanged(object sender, System.EventArgs e)
        {
            if (Auth.CurrentUser != null)
            {
                Debug.Log("[AuthManager] Auth State Changed: Signed In");
            }
            else
            {
                Debug.Log("[AuthManager] Auth State Changed: Signed Out");
                AuthEvents.TriggerLogout();
            }
        }

        public void TriggerSignIn(string providerId)
        {
            if (providers.TryGetValue(providerId, out var provider))
            {
                provider.SignIn();
            }
        }

        public void SignInWithCredential(Credential credential)
        {
            Auth?.SignInWithCredentialAsync(credential).ContinueWith(task =>
            {
                if (task.IsCanceled || task.IsFaulted)
                {
                    AuthEvents.TriggerLoginFailed(task.Exception?.Message ?? "Login failed");
                }
                else
                {
                    AuthEvents.TriggerLoginSuccess(task.Result.User.UserId);
                }
            });
        }

        public void SignOut()
        {
            Auth?.SignOut();
            AuthEvents.TriggerLogout();
        }
    }
}
