
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class LoginStateButton : MonoBehaviour
{
    public string loginProviderId = "google";
    public Button button;
    public TMP_Text label;

    private void OnEnable()
    {
        AuthEvents.OnLoginSuccess += UpdateUI;
        AuthEvents.OnLogout += UpdateUI;
        UpdateUI();
    }

    private void OnDisable()
    {
        AuthEvents.OnLoginSuccess -= UpdateUI;
        AuthEvents.OnLogout -= UpdateUI;
    }

    private void UpdateUI(string _ = null)
    {
        if (AuthSystem.AuthManager.Instance.CurrentUser != null)
        {
            label.text = "Sign Out";
            button.onClick.RemoveAllListeners();
            button.onClick.AddListener(() => AuthSystem.AuthManager.Instance.SignOut());
        }
        else
        {
            label.text = $"Login with {loginProviderId}";
            button.onClick.RemoveAllListeners();
            button.onClick.AddListener(() =>
                AuthSystem.AuthManager.Instance.TriggerSignIn(loginProviderId));
        }
    }
}
