
using System;

public static class AuthEvents
{
    public static Action<string> OnLoginSuccess;
    public static Action<string> OnLoginFailed;
    public static Action OnLogout;

    public static void TriggerLoginSuccess(string userId) => OnLoginSuccess?.Invoke(userId);
    public static void TriggerLoginFailed(string error) => OnLoginFailed?.Invoke(error);
    public static void TriggerLogout() => OnLogout?.Invoke();
}
