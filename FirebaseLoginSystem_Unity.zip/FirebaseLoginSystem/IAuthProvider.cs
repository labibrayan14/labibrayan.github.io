
using Firebase.Auth;

public interface IAuthProvider
{
    string ProviderId { get; }
    void SignIn();
}
