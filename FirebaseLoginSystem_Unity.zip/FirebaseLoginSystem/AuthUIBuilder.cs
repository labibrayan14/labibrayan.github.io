
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class AuthUIBuilder : MonoBehaviour
{
    public GameObject buttonPrefab;
    public Transform container;

    public void BuildUI()
    {
        foreach (Transform child in container)
            Destroy(child.gameObject);

        foreach (var kvp in AuthSystem.AuthManager.Instance.Providers)
        {
            var btn = Instantiate(buttonPrefab, container);
            btn.GetComponentInChildren<TMP_Text>().text = $"Login with {kvp.Key}";
            btn.GetComponent<Button>().onClick.AddListener(() =>
                AuthSystem.AuthManager.Instance.TriggerSignIn(kvp.Key));
        }
    }
}
